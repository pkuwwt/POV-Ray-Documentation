
================================================================================
SkyboxViewer v1.01                    Freeware                       20.Jan.2010
================================================================================

The SkyboxViewer is an OpenGL program for displaying and examining 3d scenarios.
Therefore 6 pictures with defined filenames (see below) will be loaded.

The SkyboxViewer uses english texts. If the language in Windows is set to
german it will automatically use the german texts.

Use key and mouse commands to change the viewing direction and the zoom value.

* Cursor keys and moving mouse with left mouse button pressed
  will change the viewing direction.

* Keys + and - respectively turning the mouse wheel will change the zoom value.

* A double click with the left mouse button will change the view between
  full screen and window mode.

* Additional commands can be started by clicking the right mouse button.

The window title displays following data:
 * the skybox name
 * the resolution of the skybox texture in pixels
 * the current viewing direction (horizontal and vertical angle)
 * the field of view angle


naming conventions of skybox pictures:
--------------------------------------

The 6 Skybox pictures has to be named as follow:

  <skyboxname>_Back.<ext>        back side picture
  <skyboxname>_Base.<ext>        down side picture
  <skyboxname>_Front.<ext>       front side picture
  <skyboxname>_Left.<ext>        left side picture
  <skyboxname>_Right.<ext>       right side picture
  <skyboxname>_Top.<ext>         upper side picture

  <skyboxname> is a free chooseable name according the naming conventions

  <ext>        defines the picture type (BMP, JPG, PNG or TGA)


arrangement and orientation of skybox pictures:
-----------------------------------------------
The skybox images has do be arranged as follow:
       Top
        !
 Left-Front-Right-Back
        !
       Base


supported picture file formats:
-------------------------------
 *.BMP    Windows Bitmap
 *.JPG    JPEG - Joint Photographic Experts Group
 *.PNG    Portable Network Graphics
 *.TGA    TARGA File Format (only unkompressed picture files are supported)


skybox picture resolution:
--------------------------
OpenGL supports only textures with a resolution of 2^n,
e.g. 256, 512 or 1024. Display the program information (F10) to view
the texture size that OpenGL will support by hardware.

OpenGL unterst�tzt nur Texturen mit einer Aufl�sung von 2^n,
also z.B. 256, 512 oder 1024 Pixel. Bis zu welcher Texturegr��e OpenGL
die Bildtexturen hardwarem��ig anzeigen kann, wird bei der Programminformation
(F10) angezeigt.

Hint: The program will get very slow, if the texture size is greater
      than the OpenGL value.


mouse commands:
---------------

 left mouse button   change viewing direction
   double click      switch full screen mode

 middle mouse button
  & mouse move       scroll to left / right

 right mouse button  popup menu

 mouse wheel         zoom in/out


key commands:
-------------

 cursor keys        change viewing direction

 W                  look up
 S                  look down

 C                  center window

 Blanc / Page Down  show next skybox
 <--   / Page Up    show previous skybox

 F1 / A             scroll to left
 F2 / D             scroll to right
      Q             stop scrolling

 F3 / +             zoom in
 F4 / -             zoom out

 F5 / L             update skybox list and reload current skybox
                    (e.g. after rotating a picture with a paint programm
                     or after swapping of 'Skyboxes' directories)

 F6 / F/Return/Tab  full screen mode on/off

 F7 / V / End       set vertical viewing direction = 0�

      H / Home      set horizontal viewing direction = 90�

 F8 / Z             zoom reset

 F9 / R             reset viewing direction, zoom and scrolling

 F10 / I            show program information

 Esc                quit program

--------------------------------------------------------------------------------
And now enjoy viewing your skyboxes...
