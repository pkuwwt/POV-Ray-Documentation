
================================================================================
Rendering Skyboxes with PovRay                                       20.Jan.2010
================================================================================

Calculation and display of Skyboxes
-----------------------------------

To be able to display a Skybox we need 6 specially made images
and a 3d program which is able to load and show these images.
With PovRay these 6 special views of a 3d scenery can be calculated.

Calculation of the images
-------------------------
The 6 images were calculated by PovRay in the way that the camera
looks in 6 directions along the axes.
The horizontal and vertical angle of view has to be therefore exactly 90�.
With this the complet environment can be represented in 6 quadratic images.

The resolution of these images must be a value of 2^n,
because the SkyboxViewer shows these images as OpenGL textures.
During the test phase a resolution of i.e. 128 is completly sufficient.
Optimal results we get if we choose a resolution of 1024x1024 or 2048x2048.
Higher resolutions do only make sense if your graphic controller supports
these higher resolutions.

And this is how you can render these images for a skybox:

* choose one of your PovRay scene files and replace your camera definition
  in 'camera {...}' by the following instructions:
    #declare camLoc = <x,y,z>;
    #include "SkyboxCamera.inc"

  Replace <x,y,z> by your coordinate of the camera position.

  In the include file 'SkyboxCamera.inc' there are the 6 main directions
  of the view defined with an angle of 90�. You don't have to change anything here!

* The calculation of the 6 images is done by the DOS batch file 'RenderSkyboxStart.bat'.
  Bevor you start this you have to choose the resolution and
  insert the correct filename of your POV-Ray scene file.
  Example:
    set res=512                 // Resolution in pixels
    set filename=Skybox_Demo1   // filename of the POV-Ray scene file to render

* The DOS batch file 'RenderSkyboxStart.bat' call for every Skybox another
  batch file named 'RenderSkybox6sides.bat', which starts POV-Ray for the final
  calculation of the 6 images.
  You have to check the installation path of your PovRay and adapt it in the file
  'RenderSkybox6sides.bat'.
  By default this is:
    povray="C:\Programme\POV-Ray\bin\pvengine.exe"

  With the batch file 'RenderSkyboxStart.bat' you can also render
  skyboxes from multiple scene files at once.
  Simply copy the line with the 'call' - instruction
  an insert the new scene file name.
     Call RenderSkybox6sides.bat <Skyboxname>  %res%

* You have to close any PovRay tasks bevor starting the batch files
  otherwise there will be an error reported.

* Finally start the batch file "RenderSkyboxStart.bat" to calculate all 6 images
  with POVRay. You will get images with the following names:
     <Skyboxname>_back.<ext>     view backwards
     <Skyboxname>_base.<ext>     view downwards
     <Skyboxname>_front.<ext>    view to the front
     <Skyboxname>_left.<ext>     view left
     <Skyboxname>_right.<ext>    view right
     <Skyboxname>_top.<ext>      view upwards


================================================================================
Displaying the Skybox
================================================================================
Start the program 'SkyboxViewer' to show the skybox.
This program expects the skybox image files in a subdirectory named 'Skyboxes'.
For more information on 'SkyboxViewer' read the according description
in the file 'SkyboxViewer_ReadMe.txt'.
